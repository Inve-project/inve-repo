
<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="main" class="main">

<section class="section dashboard">
  <div class="row">
      <!-- Left side columns -->
      <div class="col-lg-12">
          <div class="row">
          <?php if(session()->has('massage')): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
               <?php echo e(session()->get('massage')); ?>

             <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
           </div>
                
         <?php endif; ?>

            <!-- Sales Card -->
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xxl-2 col-md-3" data-bs-toggle="modal" data-bs-target="#<?php echo e($items->name); ?>">
              <div class="card info-card sales-card ">
                  <div class="card-body ">
                     <h5 class="card-title"><?php echo e($items->name); ?></h5>
                  
                        <div  style=" width:50px; height:100px;"  class="d-flex align-items-center justify-content-center">
                           <img src="itemimage/<?php echo e($items->photo); ?>" class="d-block w-100" alt="...">
                        </div> 
                     <h5> <?php echo e($items->price); ?></h5>
                   </div> 
                </div> 
            </div>
             <!-- Small Modal -->
   <div class="modal fade" id="<?php echo e($items->name); ?>" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
               <h4 class="modal-title"><b><?php echo e($items->name); ?></b></h4>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
         <form action="<?php echo e(url('sell_item')); ?>" method="POST">
             <?php echo csrf_field(); ?>
            <div class="modal-body">
               <div class="row mb-3">
                   <label for="inputEmail3" class="col-sm-2 col-form-label">Type</label>
                  <div class="col-sm-3">
                     <select id="inputState" class="form-select" name="type">
                       <option value="unity" selected>unity</option>
                       <option value="Cret">Cret</option>
                     </select>
                  </div>
               </div>
               <div class="row mb-3">
                 <label for="inputEmail3" class="col-sm-2 col-form-label">Quantity</label>
                  <div class="col-sm-2">
                    <input type="number" class="form-control" id="inputText" name="quantity">
                  </div>
               </div>
            </div>
             <input type="hidden" value="<?php echo e($items->name); ?>" name="name">
             <input type="hidden" value="<?php echo e($items->id); ?>" name="id">
             
            <div class="modal-footer">
               <button type="submit" class="btn btn-primary col-sm-3">Sell</button>
            </div>
        </form>
    </div>
   </div></div><!-- End Small Modal-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           </div>
     </div><!-- End Sales Card -->
   </div>
</section>

 

              
</div>
</main><!-- End #main -->

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>

<?php /**PATH C:\Users\Benard\Desktop\ims\resources\views/layouts/sellitem.blade.php ENDPATH**/ ?>