  <!-- Vendor JS Files -->
 <!--  <script src="admin/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>-->
 <script src="admin/assets/vendor/php-email-form/validate.js"></script>
  <script src="admin/assets/vendor/quill/quill.min.js"></script>
  <script src="admin/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="admin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="admin/assets/vendor/chart.js/chart.min.js"></script>
  <script src="admin/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="admin/assets/vendor/echarts/echarts.min.js"></script> 

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').dataTable({
            "processing": true,
            "ajax": "getreport",
            "columns": [
                {data: 'id'},
                {data: 'firstname'},
                {data: 'date'},
                {data: 'gender'},
                {data: 'status'},
                {data: 'illness'},
                {data: 'progress'},
                {data: 'motherfirstname'},
                {data: 'phone1'},
                {data: 'mkoa'},
                {data: 'wilaya'}
            ],
            dom: 'lBfrtip',
   buttons: [
    'excel'
   ],
   "lengthMenu": [ [5, 10, 50, -1], [5, 10, 50, "All"] ]
        });
    });
    </script>
<!-- 
    <script>
$(document).ready(function() {
    var printCounter = 0;
 
    // Append a caption to the table before the DataTables initialisation
    $('#example').append('<caption style="caption-side: bottom">A fictional company\'s staff table.</caption>');
 
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy',
            {
                extend: 'excel',
                messageTop: 'The information in this table is copyright to Sirius Cybernetics Corp.'
            },
            {
                extend: 'pdf',
                messageBottom: null
            },
            {
                extend: 'print',
                messageTop: function () {
                    printCounter++;
 
                    if ( printCounter === 1 ) {
                        return 'This is the first time you have printed this document.';
                    }
                    else {
                        return 'You have printed this document '+printCounter+' times';
                    }
                },
                messageBottom: null
            }
        ],
        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
    } );
} );
</script> -->

  <!-- Template Main JS File -->
  <script src="admin/assets/js/main.js"></script>
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script><?php /**PATH C:\Users\Benard\Desktop\asbaht\resources\views/layouts/script.blade.php ENDPATH**/ ?>