
<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<main id="main" class="main">

<section class="section dashboard">
  <div class="row">

    <!-- Left side columns -->
    <div class="col-lg-12">
      <div class="row">

        <!-- Customers Card -->
        <div class="col-xxl-12 col-xl-12">

          <div class="card info-card customers-card">

            <div class="card-body">
              <h5 class="card-title">Sellies of the day <span>| </span></h5>
              <table class="table table-hover" id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Type</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
            <th>Id</th>
                <th>Name</th>
                <th>Type</th>
                <th>Quantity</th>
            </tr>
        </tfoot>
    </table>

            </div>
          </div>

        </div><!-- End Customers Card -->


      </div>
    </div><!-- End Left side columns -->

  </div>
</section>



</main><!-- End #main -->

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>

<?php /**PATH C:\Users\Benard\Desktop\ims\resources\views/layouts/sells_report.blade.php ENDPATH**/ ?>