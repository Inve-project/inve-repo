
<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="<?php echo e(url('home')); ?>">
      <i class="bi bi-grid"></i>
      <span >Partient</span>

    </a>
  </li>
  <!-- End Dashboard Nav -->


</ul>

</aside><!-- End Sidebar-->




<main id="main" class="main">
<?php $__currentLoopData = $partient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<section class="section dashboard">
   <div class="row">    <!-- Left side columns -->
       <div class="col-lg-11">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Taarifa ya Mama Mzazi <?php echo e($partients->firstname); ?></h5>
                  <!-- Horizontal Form -->
            <form action="<?php echo e(url('getform2')); ?>" method="POST" class="row g-3" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la kwanza</label>
                  <input type="text" class="form-control" id="inputName5" name="firstname">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la kati</label>
                  <input type="text" class="form-control" id="inputName5" name="midlename">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la mwisho</label>
                  <input type="text" class="form-control" id="inputName5" name="lastname">
                </div>
                <div class="col-md-6">
                  <label for="inputEmail5" class="form-label">Namba ya simu 1</label>
                  <input type="number" class="form-control" id="inputEmail5" name="phone1">
                </div>
                <div class="col-md-6">
                  <label for="inputEmail5" class="form-label">Namba ya simu 2</label>
                  <input type="number" class="form-control" id="inputEmail5" name="phone2">
                </div>
                <div class="text-center">
                <button type="submit" class="btn btn-primary">Next</button>
                </div>

              </form><!-- End Horizontal Form -->

            

                </div>
            </div>
       </div>
    </div> <!-- End Left side columns -->

</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main><!-- End #main -->


<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>

<?php /**PATH C:\Users\Benard\Desktop\asbaht\resources\views/layouts/form2.blade.php ENDPATH**/ ?>