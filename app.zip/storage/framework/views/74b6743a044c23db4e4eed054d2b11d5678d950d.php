  <!-- Vendor JS Files -->
 <!--  <script src="admin/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>-->
 <script src="admin/assets/vendor/php-email-form/validate.js"></script>
  <script src="admin/assets/vendor/quill/quill.min.js"></script>
  <script src="admin/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="admin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="admin/assets/vendor/chart.js/chart.min.js"></script>
  <script src="admin/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="admin/assets/vendor/echarts/echarts.min.js"></script> 
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script> 
  <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script> 

  <!-- <script> 
  $(document).ready(function () {
    $('#example').DataTable({
        ajax: 'data/arrays.txt',
    });
});
</script>  -->

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').dataTable({
            "processing": true,
            "ajax": "getreport",
            "columns": [
                {data: 'id'},
                {data: 'name'},
                {data: 'type'},
                {data: 'quantity'}
            ]
        });
    });
    </script>

  <!-- Template Main JS File -->
  <script src="admin/assets/js/main.js"></script>
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script><?php /**PATH C:\Users\Benard\Desktop\ims\resources\views/layouts/script.blade.php ENDPATH**/ ?>