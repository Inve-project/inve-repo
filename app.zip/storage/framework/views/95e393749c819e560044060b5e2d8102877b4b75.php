
<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="<?php echo e(url('home')); ?>">
      <i class="bi bi-grid"></i>
      <span >Partient</span>

    </a>
  </li>
  <!-- End Dashboard Nav -->

  <!-- <li class="nav-item">
    <a class="nav-link collapsed" href="<?php echo e(url('seller')); ?>">
      <i class="bi bi-person"></i>
      <span ></span>
    </a>
  </li>End Profile Page Nav -->

</ul>

</aside><!-- End Sidebar-->




<main id="main" class="main">
    
<section class="section dashboard">
   <div class="row">    <!-- Left side columns -->
       <div class="col-lg-11">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Taarifa ya Makazi</h5>
               <!-- Horizontal Form -->
            <form action="<?php echo e(url('getform3')); ?>" method="POST" class="row g-3" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                
              <div class="col-md-4">
                  <label for="inputName5" class="form-label">Mkoa</label>
                  <input type="text" class="form-control" id="inputName5" name="mkoa">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">wilaya</label>
                  <input type="text" class="form-control" id="inputName5" name="wilaya">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Kata/Shehia</label>
                  <input type="text" class="form-control" id="inputName5" name="kata">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Kijiji/Mtaa</label>
                  <input type="text" class="form-control" id="inputName5" name="kijiji">
                </div>
                <div class="col-md-4"> 
                  <label for="inputName5" class="form-label">Kitongoji</label>
                  <input type="text" class="form-control" id="inputName5" name="kitongoji">
                </div>
                <div class="text-center">
                <button type="submit" class="btn btn-primary">Wasilisha</button>
                </div>

              </form><!-- End Horizontal Form -->
                </div>
            </div>
       </div>
    </div> <!-- End Left side columns -->

</section>
</main><!-- End #main -->


<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>

<?php /**PATH C:\Users\Benard\Desktop\asbaht\resources\views/layouts/form3.blade.php ENDPATH**/ ?>