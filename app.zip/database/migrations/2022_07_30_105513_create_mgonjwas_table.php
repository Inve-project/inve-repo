<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMgonjwasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mgonjwas', function (Blueprint $table) {
            $table->id();
            $table->string('userid')->nullable();
            $table->string('firstname')->nullable();
            $table->string('midlename')->nullable();
            $table->string('lastname')->nullable();
            $table->string('date')->nullable();
            $table->string('gender')->nullable();
            $table->string('status')->nullable();
            $table->string('illness')->nullable();
            $table->string('progress')->nullable();
            $table->string('childid')->nullable();
            $table->string('motherfirstname')->nullable();
            $table->string('mothermidlename')->nullable();
            $table->string('motherlastname')->nullable();
            $table->string('phone1')->nullable();
            $table->string('phone2')->nullable();
            $table->string('mkoa')->nullable();
            $table->string('wilaya')->nullable();
            $table->string('kata')->nullable();
            $table->string('kijiji')->nullable();
            $table->string('kitongoji')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mgonjwas');
    }
}
