
<!DOCTYPE html>
<html lang="en">

@include('layouts.header')

<body>

@include('layouts.topbar')
 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="{{url('home')}}">
      <i class="bi bi-grid"></i>
      <span >Partient</span>

    </a>
  </li>
  <!-- End Dashboard Nav -->
  <li class="nav-item">
    <a class="nav-link " href="{{url('form')}}">
      <i class="bi bi-grid"></i>
      <span >Partient form</span>

    </a>
  </li>

</ul>

</aside><!-- End Sidebar-->




<main id="main" class="main">
    
<section class="section dashboard">
<!-- <a href="{{url('form')}}">
     <button class="btn btn-primary">Add Partient</button>
</a> -->
<h1></h1>
@if(session()->has('massage'))
            <div class="alert alert-info alert-dismissible fade show" role="alert">
               {{session()->get('massage')}}
             <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
           </div>
                
         @endif
  <div class="row">    <!-- Left side columns -->
    <div class="col-lg-12">
    <div class="card">
            <div class="card-body">
              <h5 class="card-title">Tarifa za Watoto</h5>

              <!-- Table with stripped rows -->
              <table class="table table-hover" id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>jina la mtoto</th>
                <th>date</th>
                <th>jinsia</th>
                <th>status</th>
                <th>Tatizo</th>
                <th>maendeleo</th>
                <th>jina la mama</th>
                <th>no/simu</th>
                <th>mkoa</th>
                <th>wilaya</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Id</th>
                <th>jina la mtoto</th>
                <th>date</th>
                <th>jinsia</th>
                <th>status</th>
                <th>Tatizo</th>
                <th>maendeleo</th>
                <th>jina la mama</th>
                <th>no/simu</th>
                <th>mkoa</th>
                <th>wilaya</th>
            </tr>
        </tfoot>
    </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>
    </div><!-- End Left side columns -->
  

</div>
</section>
</main><!-- End #main -->


@include('layouts.script')

</body>

</html>

