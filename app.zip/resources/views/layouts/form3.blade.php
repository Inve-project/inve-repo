
<!DOCTYPE html>
<html lang="en">

@include('layouts.header')

<body>

@include('layouts.topbar')
 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="{{url('home')}}">
      <i class="bi bi-grid"></i>
      <span >Partient</span>

    </a>
  </li>
  <!-- End Dashboard Nav -->

  <!-- <li class="nav-item">
    <a class="nav-link collapsed" href="{{url('seller')}}">
      <i class="bi bi-person"></i>
      <span ></span>
    </a>
  </li>End Profile Page Nav -->

</ul>

</aside><!-- End Sidebar-->




<main id="main" class="main">
    
<section class="section dashboard">
   <div class="row">    <!-- Left side columns -->
       <div class="col-lg-11">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Taarifa ya Makazi</h5>
               <!-- Horizontal Form -->
            <form action="{{url('getform3')}}" method="POST" class="row g-3" enctype="multipart/form-data" >
                @csrf
                
              <div class="col-md-4">
                  <label for="inputName5" class="form-label">Mkoa</label>
                  <input type="text" class="form-control" id="inputName5" name="mkoa">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">wilaya</label>
                  <input type="text" class="form-control" id="inputName5" name="wilaya">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Kata/Shehia</label>
                  <input type="text" class="form-control" id="inputName5" name="kata">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Kijiji/Mtaa</label>
                  <input type="text" class="form-control" id="inputName5" name="kijiji">
                </div>
                <div class="col-md-4"> 
                  <label for="inputName5" class="form-label">Kitongoji</label>
                  <input type="text" class="form-control" id="inputName5" name="kitongoji">
                </div>
                <div class="text-center">
                <button type="submit" class="btn btn-primary">Wasilisha</button>
                </div>

              </form><!-- End Horizontal Form -->
                </div>
            </div>
       </div>
    </div> <!-- End Left side columns -->

</section>
</main><!-- End #main -->


@include('layouts.script')

</body>

</html>

