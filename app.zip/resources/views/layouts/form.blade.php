
<!DOCTYPE html>
<html lang="en">

@include('layouts.header')

<body>

@include('layouts.topbar')
 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="{{url('home')}}">
      <i class="bi bi-grid"></i>
      <span >Partient</span>

    </a>
  </li>
  <!-- End Dashboard Nav -->
  <li class="nav-item">
    <a class="nav-link " href="{{url('form')}}">
      <i class="bi bi-grid"></i>
      <span >Partient form</span>

    </a>
  </li>

</ul>

</aside><!-- End Sidebar-->




<main id="main" class="main">
    
<section class="section dashboard">
   <div class="row">    <!-- Left side columns -->
       <div class="col-lg-11">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Taarifa ya Mtoto</h5>
                  <!-- Horizontal Form -->
                <form  method="POST" action="{{url('getform')}}"class="row g-3">
                @csrf
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la kwanza</label>
                  <input type="text" class="form-control" id="inputName5" name="firstname">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la kati</label>
                  <input type="text" class="form-control" id="inputName5" name="midlename">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la mwisho</label>
                  <input type="text" class="form-control" id="inputName5" name="lastname">
                </div>
                <div class="col-md-4">
                  <label for="inputEmail5" class="form-label">Tarehe ya kuzaliwa</label>
                  <input type="date" class="form-control" id="inputEmail5" name="date">
                </div>
                <div class="col-md-4">
                  <label for="inputState" class="form-label">Jinsia</label>
                  <select id="inputState" class="form-select" name="gender">
                    <option selected>Chagua...</option>
                    <option value="ME">Me</option>
                    <option value="KE">Ke</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label for="inputState" class="form-label">Status</label>
                  <select id="inputState" class="form-select" name="status">
                    <option selected>Chagua...</option>
                    <option value="Alive">Alive</option>
                    <option value="Died">Died</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label for="inputState" class="form-label">Tatizo la Mtoto</label>
                  <select id="inputState" class="form-select" name="illness">
                    <option selected>Chagua...</option>
                    <option value="HC">HC</option>
                    <option value="SB">SB</option>
                    <option value="SBH">SBH</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label for="inputPassword5" class="form-label">Maendeleo ya Mtoto</label>
                  <input type="txt" class="form-control" id="inputPassword5" name="progress">
                </div>

                <h5 class="card-title">Taarifa ya Mama Mzazi</h5>

                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la kwanza</label>
                  <input type="text" class="form-control" id="inputName5" name="motherfirstname">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la kati</label>
                  <input type="text" class="form-control" id="inputName5" name="mothermidlename">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Jina la mwisho</label>
                  <input type="text" class="form-control" id="inputName5" name="motherlastname">
                </div>
                <div class="col-md-6">
                  <label for="inputEmail5" class="form-label">Namba ya simu 1</label>
                  <input type="number" class="form-control" id="inputEmail5" name="phone1">
                </div>
                <div class="col-md-6">
                  <label for="inputEmail5" class="form-label">Namba ya simu 2</label>
                  <input type="number" class="form-control" id="inputEmail5" name="phone2">
                  </div>

                <h5 class="card-title">Taarifa ya Makazi</h5>

              <div class="col-md-4">
                  <label for="inputName5" class="form-label">Mkoa</label>
                  <input type="text" class="form-control" id="inputName5" name="mkoa">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">wilaya</label>
                  <input type="text" class="form-control" id="inputName5" name="wilaya">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Kata/Shehia</label>
                  <input type="text" class="form-control" id="inputName5" name="kata">
                </div>
                <div class="col-md-4">
                  <label for="inputName5" class="form-label">Kijiji/Mtaa</label>
                  <input type="text" class="form-control" id="inputName5" name="kijiji">
                </div>
                <div class="col-md-4"> 
                  <label for="inputName5" class="form-label">Kitongoji</label>
                  <input type="text" class="form-control" id="inputName5" name="kitongoji">
                </div>


                <div class="text-center">
                <button type="submit" class="btn btn-primary">Wasilisha</button>/
                </div>

              </form><!-- End Horizontal Form -->

            

                </div>
            </div>
       </div>
    </div> <!-- End Left side columns -->

</section>
</main><!-- End #main -->


@include('layouts.script')

</body>

</html>

